const express = require('express');
const app = express();
const path = require('path');
const fs = require('fs');
const axios = require('axios');
const bodyParser = require('body-parser');

// Set EJS as templating engine
app.set('view engine', 'ejs');
app.use(express.static(path.join(__dirname, 'public')));
app.use(bodyParser.urlencoded({ extended: true }));

// Function to get media files from 'foto' and 'video' folders
function getDefaultMedia() {
    const photoDir = path.join(__dirname, 'public', 'foto');
    const videoDir = path.join(__dirname, 'public', 'video');

    // Read images from 'foto' folder
    const photos = fs.readdirSync(photoDir).map(file => `/foto/${file}`);

    // Read videos from 'video' folder
    const videos = fs.readdirSync(videoDir).map(file => `/video/${file}`);

    return { photos, videos };
}

// Route to gallery
app.get('/', (req, res) => {
    const media = getDefaultMedia(); // Get default media from local folders
    res.render('gallery', { images: media.photos, videos: media.videos, error: null });
});

// Handle search request
app.post('/search', async (req, res) => {
    const text = req.body.query;
    const apiOption = req.body.api_option;
    const apikey = 'pinaaaaaasecccpaull210705080406';  // Masukkan API key Anda di sini

    let apiUrl;
    if (apiOption === 'beta') {
        apiUrl = `https://api.betabotz.eu.org/api/search/pinterest?text1=${text}&apikey=${apikey}`;
    } else if (apiOption === 'widi') {
        apiUrl = `https://widipe.com/pinterest?query=${text}`;
    }

    try {
        const response = await axios.get(apiUrl);

        // Mendapatkan gambar dari response API
        const images = response.data.result;

        res.render('gallery', { images, videos: [], error: null });
    } catch (error) {
        res.render('gallery', { images: [], videos: [], error: 'Failed to fetch images.' });
    }
});

const port = 5001; // Atur port selain 2000, 3000, 8000, dan 6000
app.listen(port, () => {
    console.log(`Server is running on http://localhost:${port}`);
});
