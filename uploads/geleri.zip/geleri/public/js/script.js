// URL untuk JSON media
const mediaUrl = 'https://raw.githubusercontent.com/dreamliner21/mainDB/refs/heads/master/geleri.json';

// Function untuk toggle fullscreen
function toggleFullscreen(videoContainer, button) {
    if (!document.fullscreenElement) {
        videoContainer.requestFullscreen().catch(err => {
            alert(`Error attempting to enter fullscreen mode: ${err.message} (${err.name})`);
        });
        button.querySelector('i').classList.remove('bi-arrows-fullscreen');
        button.querySelector('i').classList.add('bi-arrows-collapse');
    } else {
        document.exitFullscreen();
        button.querySelector('i').classList.remove('bi-arrows-collapse');
        button.querySelector('i').classList.add('bi-arrows-fullscreen');
    }
}

// Function untuk fetch data dari URL JSON
async function fetchMedia() {
    try {
        const response = await fetch(mediaUrl);
        const data = await response.json();
        return data.media;
    } catch (error) {
        console.error('Error fetching media:', error);
        return { images: [], videos: [] };  // Fallback jika error
    }
}

// Function untuk render gambar dan video
function renderMedia(media) {
    // Render photos
    const photoGallery = document.getElementById('photo-gallery');
    photoGallery.innerHTML = ''; // Clear previous photos

    media.images.forEach((image, index) => {
        const photoDiv = document.createElement('div');
        photoDiv.classList.add('col-md-4');
        photoDiv.innerHTML = `
            <div class="card mb-4">
                <img src="${image}" class="card-img-top" alt="Image ${index + 1}">
            </div>
        `;
        photoGallery.appendChild(photoDiv);
    });

    // Render videos
    const videoGallery = document.getElementById('video-gallery');
    videoGallery.innerHTML = ''; // Clear previous videos

    media.videos.forEach((video, index) => {
        const videoDiv = document.createElement('div');
        videoDiv.classList.add('col-md-4');
        videoDiv.innerHTML = `
            <div class="card mb-4">
                <div class="video-container">
                    <video id="video${index}" class="card-img-top">
                        <source src="${video}" type="video/mp4">
                    </video>
                    <!-- Overlay Icons Play/Pause and Fullscreen -->
                    <div class="video-overlay d-flex justify-content-center align-items-center">
                        <button class="btn btn-primary toggle-play-btn" data-video-id="video${index}">
                            <i class="bi bi-play"></i>
                        </button>
                        <button class="btn btn-primary toggle-fullscreen-btn" data-video-id="video${index}">
                            <i class="bi bi-arrows-fullscreen"></i>
                        </button>
                    </div>
                </div>
            </div>
        `;
        videoGallery.appendChild(videoDiv);
    });

    // Attach event listeners for play/pause and fullscreen toggle buttons
    document.querySelectorAll('.toggle-play-btn').forEach(button => {
        button.addEventListener('click', function() {
            const video = document.getElementById(this.getAttribute('data-video-id'));
            const icon = this.querySelector('i');

            if (video.paused) {
                video.play();
                icon.classList.remove('bi-play');
                icon.classList.add('bi-pause');
            } else {
                video.pause();
                icon.classList.remove('bi-pause');
                icon.classList.add('bi-play');
            }
        });
    });

    document.querySelectorAll('.toggle-fullscreen-btn').forEach(button => {
        button.addEventListener('click', function() {
            const videoContainer = this.closest('.video-container');
            toggleFullscreen(videoContainer, this);
        });
    });
}

// Function untuk mereset galeri
async function resetGallery() {
    const media = await fetchMedia();
    renderMedia(media);
}

// Inisialisasi galeri saat halaman dimuat
window.onload = async function () {
    await resetGallery();
};

// Function untuk memilih API saat pencarian
function selectApi(api) {
    document.getElementById('apiOption').value = api;
}
